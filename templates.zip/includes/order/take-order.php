<?php
if ( ! defined( 'ABSPATH' ) ) exit;

global $wpdb;
$current_user_id = get_current_user_id();


if ( current_user_can('administrator') ) {
    if ( ! session_id() ) session_start();
    $restaurant_id = isset($_SESSION['qrrs_active_res_id']) 
        ? intval($_SESSION['qrrs_active_res_id']) : 0;
} else {
    $staff_info = $wpdb->get_row($wpdb->prepare(
        "SELECT restaurant_id FROM {$wpdb->prefix}qrrs_staff WHERE user_id = %d AND status = 'active'",
        $current_user_id
    ));
    $restaurant_id = $staff_info ? $staff_info->restaurant_id : intval( get_user_meta( $current_user_id, 'assigned_restaurant', true ) );
}

if (!$restaurant_id) {
    echo '<div style="padding:50px; text-align:center;"><h3>Please select a restaurant from the dashboard first.</h3></div>';
    return;
}

$res_info = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}qrrs_restaurants WHERE id = %d", $restaurant_id));
$db_tax = $res_info->tax_percent ?? 0;
$db_sc  = $res_info->service_charge_percent ?? 0;

$tables = $wpdb->get_results($wpdb->prepare("
    SELECT t.*, 
        o.order_status, 
        o.id AS active_order_id,
        o.waiter_id,
        u.display_name as waiter_name
    FROM {$wpdb->prefix}qrrs_tables t
    LEFT JOIN {$wpdb->prefix}qrrs_orders o ON t.table_name = o.table_name 
        AND o.restaurant_id = %d 
        AND o.order_status NOT IN ('completed','cancelled','billing')
        AND DATE(o.created_at) = CURDATE()
    LEFT JOIN {$wpdb->prefix}users u ON o.waiter_id = u.ID
    WHERE t.restaurant_id = %d
    GROUP BY t.table_name
    ORDER BY CAST(SUBSTRING_INDEX(t.table_name,' ',-1) AS UNSIGNED) ASC, t.table_name ASC
", $restaurant_id, $restaurant_id));

$categories = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}qrrs_categories WHERE restaurant_id = %d ORDER BY id ASC", $restaurant_id));
$items = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}qrrs_items WHERE restaurant_id = %d", $restaurant_id));

$today_start = current_time('Y-m-d 00:00:00');
$today_end   = current_time('Y-m-d 23:59:59');

$occupied_tables_data = $wpdb->get_results($wpdb->prepare("
    SELECT 
        o.table_name,
        o.created_at,
        o.grand_total,
        COUNT(oi.id) as item_count,
        u.display_name as taken_by
    FROM {$wpdb->prefix}qrrs_orders o
    LEFT JOIN {$wpdb->prefix}users u ON o.waiter_id = u.ID
    LEFT JOIN {$wpdb->prefix}qrrs_order_items oi ON o.id = oi.order_id
    WHERE o.restaurant_id = %d 
    AND o.order_status NOT IN ('completed', 'cancelled')
    AND o.created_at BETWEEN %s AND %s
    GROUP BY o.table_name
", $restaurant_id, $today_start, $today_end));

$occupied_map = [];
foreach($occupied_tables_data as $ot) {
    $occupied_map[$ot->table_name] = $ot;
}
$occupied_table_names = array_keys($occupied_map);

$plugin_url = plugin_dir_url(dirname(dirname(__FILE__)));
$can_use_delivery = function_exists( 'qrrs_can_use_feature' ) ? qrrs_can_use_feature( 'delivery' ) : true;
$svc_on = function_exists( 'qrrs_online_services_for' ) ? qrrs_online_services_for( intval( $restaurant_id ) ) : [ 'dine_in' => true, 'take_out' => true, 'delivery' => true ];

?>



<div class="pos-wrapper">
    <div id="pos-overlay" class="pos-overlay">
        <div id="step-type" class="selection-card">
            <h1 style="margin-bottom:20px;">New Order</h1>
            <div style="display:grid; grid-template-columns: 1fr 1fr 1fr; gap:20px;">
                <div class="cat-item" style="border:1px solid #eee; border-radius:15px; padding:25px; <?php echo empty( $svc_on['dine_in'] ) ? 'display:none;' : ''; ?>" onclick="selectType('dine_in')">🍽️<br>Dine In</div>
                <div class="cat-item" style="border:1px solid #eee; border-radius:15px; padding:25px; <?php echo empty( $svc_on['take_out'] ) ? 'display:none;' : ''; ?>" onclick="selectType('take_out')">🛍️<br>Take Out</div>
                <div class="cat-item <?php echo $can_use_delivery ? '' : 'disabled-option'; ?>" style="<?php echo empty( $svc_on['delivery'] ) ? 'display:none;' : ''; ?>border:1px solid #eee; border-radius:15px; padding:25px; <?php echo $can_use_delivery ? 'cursor:pointer;' : 'opacity:0.6; cursor:not-allowed;'; ?> position: relative;" onclick="selectType('delivery')" title="<?php echo $can_use_delivery ? 'Delivery' : 'Available in Pro'; ?>">
                    🚚<br>Delivery
                    <?php if ( ! $can_use_delivery ) : ?>
                        <small style="display:block; font-size:10px; color:#ef4444; margin-top:5px; font-weight:bold;">Pro</small>
                    <?php endif; ?>
                </div>
                <div class="cat-item" style="border:1px solid #eee; border-radius:15px; padding:25px; <?php echo empty( $svc_on['self_service'] ) ? 'display:none;' : ''; ?>" onclick="selectSelfService()">🧾<br>Self-service<small style="display:block; font-size:11px; color:#64748b; margin-top:4px;">Pay at counter</small></div>
            </div>
        </div>
        <div id="step-table" class="selection-card" style="display:none;">
            <div class="table-modal-header">
                <h3>🪑 Select Table</h3>
                <div class="table-legend">
                    <div class="legend-dot"><span style="background:#22c55e;"></span> Free</div>
                    <div class="legend-dot"><span style="background:#f97316;"></span> Occupied</div>
                </div>
            </div>

            <div class="table-grid-container">
                <?php 
                $free_count = 0;
                $occupied_count = 0;
                foreach($tables as $t): 
                    $is_occupied = in_array($t->table_name, $occupied_table_names);
                    $capacity = !empty($t->capacity) ? intval($t->capacity) : 4;
                    
                    if($is_occupied) {
                        $occupied_count++;
                        $odata = $occupied_map[$t->table_name] ?? null;
                        $taken_by = $odata ? ($odata->taken_by ?: 'Staff') : 'Customer';
                        $item_count = $odata ? intval($odata->item_count) : 0;
                        
                        // WordPress Timezone Fix & Placement Time Formatting
                        if ( $odata ) {
                            $order_timestamp = qrrs_local_ts($odata->created_at);
                            $time_ago        = human_time_diff($order_timestamp, current_time('timestamp')) . ' ago';
                            $placement_time  = wp_date('h:i A', $order_timestamp); // e.g. 08:43 AM
                        } else {
                            $time_ago        = '';
                            $placement_time  = '';
                        }

                        $grand_total = $odata ? number_format($odata->grand_total, 0) : '0';
                        $onclick = "showOccupiedAlert('" . esc_js($t->table_name) . "', '" . esc_js($taken_by) . "', '{$item_count}', '{$time_ago}', '{$placement_time}')";
                    } else {
                        $free_count++;
                        $onclick = "selectTable({$t->id}, '" . esc_js($t->table_name) . "')";
                    }

                    $chair_icons = '';
                    for($i = 0; $i < min($capacity, 6); $i++) $chair_icons .= '🪑';
                ?>
                <div class="tbl-card <?php echo $is_occupied ? 'occupied' : 'free'; ?>" 
                    onclick="<?php echo $onclick; ?>">
                    
                    <?php if($is_occupied): ?>
                    <div class="tbl-tooltip">
                        👤 <?php echo esc_html($taken_by); ?> · <?php echo $item_count; ?> items · <?php echo $time_ago; ?>
                    </div>
                    <?php endif; ?>

                    <span class="tbl-icon">
                        <img src="<?php echo $is_occupied 
                            ? esc_url($plugin_url . 'assets/images/table-occupied.png')
                            : esc_url($plugin_url . 'assets/images/table-free.png'); ?>" 
                            style="width:auto; height:45px; object-fit:contain;">
                    </span>
                    <div class="tbl-name"><?php echo esc_html($t->table_name); ?></div>
                    <div class="tbl-capacity">👥 <?php echo $capacity; ?> seats</div>
                    <div class="tbl-status-pill">
                        <?php echo $is_occupied ? '● Occupied' : '● Free'; ?>
                    </div>
                    <?php if($is_occupied): ?>
                    <div class="tbl-waiter-info">
                        <!-- <div class="tbl-waiter-avatar"><?php echo strtoupper(substr($taken_by, 0, 1)); ?></div> -->
                        <div class="tbl-waiter-name"> <?php echo esc_html($taken_by); ?></div>
                    </div>
                    <div class="tbl-order-meta"><?php echo $item_count; ?> items · <?php echo $time_ago; ?></div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="table-modal-footer">
                <div class="table-stats-text">
                    <strong><?php echo $free_count; ?></strong> free · 
                    <strong><?php echo $occupied_count; ?></strong> occupied
                </div>
                <button onclick="jQuery('#step-table').hide(); jQuery('#step-type').show();" 
                        style="background:none; border:1px solid #e2e8f0; padding:8px 16px; border-radius:8px; color:#64748b; cursor:pointer; font-size:13px; font-weight:600;">
                    ← Back
                </button>
            </div>
        </div>
    </div>

    <div class="sidebar-left">
        <div class="cat-item active" data-cat="all">🏠<h4>ALL</h4></div>
        <?php foreach($categories as $cat): 
        
            $c_img = !empty($cat->image_url) ? $cat->image_url : (!empty($cat->image) ? $cat->image : '');
        ?>
            <div class="cat-item" data-cat="<?php echo $cat->id; ?>">
                <?php if($c_img): ?>
                    <img src="<?php echo esc_url($c_img); ?>" class="cat-icon" onerror="this.src='https://via.placeholder.com/50'">
                <?php else: ?>
                    <div class="cat-icon" style="background:#eee; display:flex; align-items:center; justify-content:center; font-size:20px; border-radius:50%; margin: 0 auto 5px;">📁</div>
                <?php endif; ?>
                <h4><?php echo esc_html($cat->category_name); ?></h4>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="main-content">
        <div class="item-grid">
            <?php foreach($items as $item): 
            
                $i_img = !empty($item->image_url) ? $item->image_url : (!empty($item->item_image) ? $item->item_image : '');
                $item_offers = function_exists( 'qrrs_best_offer_for_item' ) ? [
                    'offer'          => qrrs_best_offer_for_item( $restaurant_id, (int) $item->id, (float) $item->price ),
                    'buyget'         => qrrs_buyget_for_item( $restaurant_id, (int) $item->id ),
                    'variant_offers' => qrrs_variant_offers_for_item( $restaurant_id, (int) $item->id ),
                    'offer_names'    => qrrs_offer_names_for_item( $restaurant_id, (int) $item->id ),
                ] : [];
                $item_json = json_encode( array_merge( (array) $item, $item_offers ) );
                $__base = (float) $item->price; $__op = $__base; $__o = $item_offers['offer'] ?? null;
                if ( $__o && 'buyget' !== $__o['type'] ) {
                    $__op = ( 'percent' === $__o['type'] ) ? round( $__base * ( 1 - $__o['amount'] / 100 ), 2 ) : round( max( 0, $__base - $__o['amount'] ), 2 );
                }
                $is_avail = isset($item->is_available) ? intval($item->is_available) : 1;
            ?>
            <div class="item-card <?php echo ($is_avail === 0) ? 'out-of-stock' : ''; ?>" 
                id="card-<?php echo $item->id; ?>" 
                data-cat-id="<?php echo $item->category_id; ?>"
                onclick='<?php echo ($is_avail === 1) ? "prepareItem($item_json)" : ""; ?>'>
                
                <div class="item-qty-badge" id="badge-<?php echo $item->id; ?>">0</div>
                
                <img src="<?php echo esc_url($i_img); ?>" class="item-img" onerror="this.src='https://via.placeholder.com/300x150?text=Food'">
                
                <div style="padding:12px;">
                    <h4 style="margin:0 0 5px 0; font-size:14px; color:#334155; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                        <?php echo esc_html($item->item_name); ?>
                    </h4>
                    <div>
                        <?php if ( $__op < $__base ) : ?>
                            <s style="color:#94a3b8; font-size:12px; margin-right:6px;"><?php echo number_format( $__base, 2 ); ?>৳</s>
                            <b style="color:#dc2626; font-size:15px;"><?php echo number_format( $__op, 2 ); ?>৳</b>
                        <?php else : ?>
                            <span style="font-weight:700; color:var(--primary); font-size:15px;"><?php echo number_format( $__base, 2 ); ?>৳</span>
                        <?php endif; ?>
                        <?php foreach ( ( $item_offers['offer_names'] ?? [] ) as $__n ) : if ( $__o && $__n === $__o['name'] ) continue; ?>
                            <span style="display:block; margin-top:4px; background:#fef3c7; color:#92400e; font-size:10px; font-weight:800; padding:2px 6px; border-radius:5px; width:max-content;"><?php echo esc_html( $__n ); ?></span>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="sidebar-right">
        <div style="padding:20px; border-bottom:1px solid #f1f5f9;">
            <div style="font-weight:bold; font-size:18px;">Order Details</div>
            <small id="order-meta-label" style="color:var(--primary); font-weight:bold;"></small>
        </div>
        <div id="cart-list" style="flex:1; overflow-y:auto; padding:15px;"></div>
        <div id="cart-summary" style="padding:20px; background:#f8fafc; border-top:1px solid #e2e8f0;"></div>
    </div>
</div>

<div id="vModal" class="v-modal">
    <div class="v-modal-content" id="vBody"></div>
</div>


<div id="successPopup" class="v-modal" style="display:none; z-index: 9999;">
    <div class="v-modal-content" style="text-align:center; padding: 30px; border-radius: 15px; max-width: 350px;">
        <div class="success-icon" style="margin-bottom: 15px;">
            <svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="20 6 9 17 4 12"></polyline>
            </svg>
        </div>
        <h2 style="margin: 0 0 10px 0; color: #1e293b; font-size: 20px;">Order Placed</h2>
        <p style="color: #64748b; font-size: 14px; margin: 0;">The order has been recorded successfully.</p>
        
        <div style="margin-top: 20px; font-size: 12px; color: #94a3b8; border-top: 1px solid #f1f5f9; pt: 15px;">
            Refreshing in <span id="timer" style="font-weight: bold; color: #1e293b;">3</span>s...
        </div>
    </div>
</div>

<style>
#successPopup {
    background: rgba(0, 0, 0, 0.5) !important;
    backdrop-filter: blur(2px);
}
.success-icon {
    animation: popIn 0.4s ease-out;
}
@keyframes popIn {
    0% { transform: scale(0.5); opacity: 0; }
    100% { transform: scale(1); opacity: 1; }
}
</style>

<script>
const TAX_RATE = <?php echo floatval($db_tax); ?>;
const SC_RATE  = <?php echo floatval($db_sc); ?>;
const AJAX_URL = '<?php echo admin_url("admin-ajax.php"); ?>';
const NONCE    = '<?php echo wp_create_nonce("qr_order_nonce"); ?>';
const CAN_DELIVERY = <?php echo $can_use_delivery ? 'true' : 'false'; ?>;

let cart = [];
let orderMeta = { type: '', table_id: 0, table_name: '' };
let deliveryCustomer = null;

function escapeDeliveryField(value) {
    return String(value || '').replace(/[&<>"']/g, function(character) {
        return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[character];
    });
}


function selectType(t) { 
    if(t === 'delivery' && !CAN_DELIVERY) {
        alert('Delivery orders are available in Pro only.');
        return;
    }

    if (t === 'delivery') {
        openDeliveryCustomerForm();
        return;
    }

    orderMeta.type = t; 
    if(t === 'dine_in') { jQuery('#step-type').hide(); jQuery('#step-table').show(); } 
    else {
        orderMeta.table_id = 0;
        orderMeta.table_name = (t === 'delivery') ? 'Delivery' : 'Take Out';
        finalizeSelection();
    }
}
function selectTable(id, n) { orderMeta.table_id = id; orderMeta.table_name = n; finalizeSelection(); }
function selectSelfService() { orderMeta.type = 'self_service'; orderMeta.table_id = 0; orderMeta.table_name = 'Self-service'; finalizeSelection(); }
function finalizeSelection() {
    // Close the type/table steps immediately so the menu is always reachable
    jQuery('#step-type, #step-table').hide();
    jQuery('#pos-overlay').hide();
    jQuery('#order-meta-label').text(orderMeta.table_name);
    console.log('[take-order] selected', orderMeta.type, orderMeta.table_id, orderMeta.table_name);
}

function openDeliveryCustomerForm() {
    document.getElementById('vBody').innerHTML = `
        <div style="padding:4px;">
            <h3 style="margin:0 0 8px; color:#1e293b;">Delivery Customer Details</h3>
            <p style="margin:0 0 16px; color:#64748b; font-size:13px;">Complete these details before creating the delivery order.</p>
            <label style="display:block; font-size:13px; font-weight:700; margin:10px 0 5px;">Customer Name *</label>
            <input id="delivery-customer-name" type="text" value="${escapeDeliveryField(deliveryCustomer ? deliveryCustomer.name : '')}" style="width:100%; box-sizing:border-box; padding:11px; border:1px solid #cbd5e1; border-radius:7px;">
            <label style="display:block; font-size:13px; font-weight:700; margin:10px 0 5px;">Phone Number *</label>
            <input id="delivery-customer-phone" type="tel" value="${escapeDeliveryField(deliveryCustomer ? deliveryCustomer.phone : '')}" style="width:100%; box-sizing:border-box; padding:11px; border:1px solid #cbd5e1; border-radius:7px;">
            <label style="display:block; font-size:13px; font-weight:700; margin:10px 0 5px;">Delivery Address *</label>
            <textarea id="delivery-customer-address" rows="3" style="width:100%; box-sizing:border-box; padding:11px; border:1px solid #cbd5e1; border-radius:7px; resize:vertical;">${escapeDeliveryField(deliveryCustomer ? deliveryCustomer.address : '')}</textarea>
            <label style="display:block; font-size:13px; font-weight:700; margin:10px 0 5px;">Delivery Note</label>
            <textarea id="delivery-customer-note" rows="2" style="width:100%; box-sizing:border-box; padding:11px; border:1px solid #cbd5e1; border-radius:7px; resize:vertical;">${escapeDeliveryField(deliveryCustomer ? deliveryCustomer.note : '')}</textarea>
            <button onclick="confirmDeliveryCustomer()" class="btn-place-order" style="margin-top:15px; width:100%;">Continue to Order</button>
            <button onclick="closeM()" style="width:100%; background:none; border:none; margin-top:10px; color:#64748b; cursor:pointer;">Cancel</button>
        </div>`;
    document.getElementById('vModal').style.display = 'flex';
}

function confirmDeliveryCustomer() {
    const name = document.getElementById('delivery-customer-name').value.trim();
    const phone = document.getElementById('delivery-customer-phone').value.trim();
    const address = document.getElementById('delivery-customer-address').value.trim();
    const note = document.getElementById('delivery-customer-note').value.trim();

    if (!name || !phone || !address) {
        alert('Customer name, phone number, and delivery address are required.');
        return;
    }

    deliveryCustomer = { name, phone, address, note };
    orderMeta.type = 'delivery';
    orderMeta.table_id = 0;
    orderMeta.table_name = 'Delivery';
    closeM();
    finalizeSelection();
}


let pendingItem = null;
let optionCache = {};

function escapeHtml(t) {
    return String(t).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function parseLegacyAddons(item) {
    let rawVar = item.variants || item.variants_json || "";
    let list = [];
    try {
        if (typeof rawVar === 'string' && rawVar.trim() !== "" && rawVar !== "[]") list = JSON.parse(rawVar);
        else if (Array.isArray(rawVar)) list = rawVar;
    } catch(e) { list = []; }
    return Array.isArray(list) ? list : [];
}

function fetchItemOptions(itemId) {
    if (optionCache[itemId]) return Promise.resolve(optionCache[itemId]);
    const body = new URLSearchParams({ action: 'qrrs_get_item_options', restaurant_id: <?php echo intval($restaurant_id); ?>, item_id: itemId });
    return fetch(AJAX_URL, { method: 'POST', body: body })
        .then(r => r.json())
        .then(j => {
            const groups = (j && j.success && j.data && j.data.groups) ? j.data.groups : [];
            optionCache[itemId] = groups;
            return groups;
        })
        .catch(() => []);
}

function prepareItem(item) {
    pendingItem = item;
    const legacy = parseLegacyAddons(item);
    fetchItemOptions(item.id).then(groups => {
        if (groups.length === 0 && legacy.length === 0) {
            addToCart(item, [], [], [], parseFloat(item.price));
            return;
        }
        renderOptionModal(item, groups, legacy);
    });
}

function renderOptionModal(item, groups, legacy) {
    let html = `<h3>${escapeHtml(item.item_name)}</h3><p style="color:#64748b; font-size:14px;">Customize order:</p>`;

    groups.forEach(g => {
        html += `<p style="font-weight:700; margin:14px 0 6px;">${escapeHtml(g.name)}${g.type === 'size' && g.required ? ' <span style="color:#dc2626;">*</span>' : ''}</p>`;
        if (g.type === 'size') {
            if (!g.required) {
                html += `<label style="display:flex; align-items:center; gap:12px; padding:10px; border:1px solid #e2e8f0; border-radius:12px; margin-bottom:8px; cursor:pointer;">
                    <input type="radio" name="size_g_${g.id}" value="0" checked data-price="0" data-name="">
                    <span style="font-weight:500;">None</span></label>`;
            }
            g.values.forEach(v => {
                html += `<label style="display:flex; align-items:center; gap:12px; padding:12px; border:1px solid #e2e8f0; border-radius:12px; margin-bottom:8px; cursor:pointer;">
                    <input type="radio" name="size_g_${g.id}" class="v_size_rb" value="${v.id}" data-price="${v.price}" data-name="${escapeHtml(v.name)}">
                    <span style="font-weight:500;">${escapeHtml(v.name)}</span>
                    <span style="margin-left:auto; font-weight:700;">${Number(v.price).toFixed(2)}৳</span></label>`;
            });
        } else {
            g.values.forEach(v => {
                html += `<label style="display:flex; align-items:center; gap:12px; padding:12px; border:1px solid #e2e8f0; border-radius:12px; margin-bottom:10px; cursor:pointer;">
                    <input type="checkbox" class="v_opt_cb" value="${escapeHtml(v.name)}" data-price="${v.price}" data-name="${escapeHtml(v.name)}" style="width:20px; height:20px; accent-color:var(--primary);">
                    <span style="font-weight:500;">${escapeHtml(v.name)}</span>
                    <span style="margin-left:auto; color:#64748b;">+${Number(v.price).toFixed(2)}৳</span></label>`;
            });
        }
    });

    if (legacy.length) {
        html += `<p style="font-weight:700; margin:14px 0 6px;">Extras</p>`;
        legacy.forEach(v => {
            html += `<label style="display:flex; align-items:center; gap:12px; padding:12px; border:1px solid #e2e8f0; border-radius:12px; margin-bottom:10px; cursor:pointer;">
                <input type="checkbox" class="v_opt_cb" value="${escapeHtml(v)}" data-price="0" data-name="${escapeHtml(v)}" style="width:20px; height:20px; accent-color:var(--primary);">
                <span style="font-weight:500;">${escapeHtml(v)}</span></label>`;
        });
    }

    html += `<p id="vTotal" style="font-weight:700; text-align:right; margin:12px 0;"></p>`;
    html += `<button onclick="confirmAddPending()" class="btn-place-order">Add to Order</button>`;
    html += `<button onclick="closeM()" style="width:100%; background:none; border:none; margin-top:10px; color:#94a3b8; cursor:pointer;">Cancel</button>`;

    document.getElementById('vBody').innerHTML = html;
    document.getElementById('vModal').style.display = 'flex';
    document.querySelectorAll('#vBody input').forEach(el => el.addEventListener('change', updatePendingTotal));
    updatePendingTotal();
}

function pendingSelection() {
    const hasRequiredSize = document.querySelectorAll('.v_size_rb').length > 0 && pendingRequiredSizeCount() > 0;
    let price = hasRequiredSize ? 0 : parseFloat(pendingItem.price);
    let sizeIds = [], sizeNames = [], addons = [];

    document.querySelectorAll('input[type="radio"]:checked').forEach(rb => {
        if (rb.value === '0') return;
        sizeIds.push(rb.value);
        sizeNames.push(rb.dataset.name);
        price += parseFloat(rb.dataset.price || 0);
    });
    document.querySelectorAll('.v_opt_cb:checked').forEach(cb => {
        addons.push(cb.dataset.name);
        price += parseFloat(cb.dataset.price || 0);
    });
    return { sizeIds, sizeNames, addons, price };
}

function pendingRequiredSizeCount() {
    return (optionCache[pendingItem.id] || []).filter(g => g.type === 'size' && g.required).length;
}

function updatePendingTotal() {
    const sel = pendingSelection();
    const el = document.getElementById('vTotal');
    if (el) el.textContent = 'Total: ' + sel.price.toFixed(2) + '৳';
}

function confirmAddPending() {
    const groups = optionCache[pendingItem.id] || [];
    for (const g of groups) {
        if (g.type === 'size' && g.required) {
            const chosen = document.querySelector(`input[name="size_g_${g.id}"]:checked`);
            if (!chosen) { alert('Please choose: ' + g.name); return; }
        }
    }
    const sel = pendingSelection();
    addToCart(pendingItem, sel.addons, sel.sizeIds, sel.sizeNames, sel.price);
    closeM();
}

function linePriceT(base, o) {
    if (!o || o.type === 'buyget') return base;
    if (o.type === 'percent') return Math.max(0, Math.round(base * (1 - o.amount / 100) * 100) / 100);
    return Math.max(0, Math.round((base - o.amount) * 100) / 100);
}
function pickOfferT(item, sizeIds, base) {
    let best = item.offer || null;
    const disc = (o, p) => !o ? 0 : (o.type === 'buyget' ? 0 : (o.type === 'percent' ? p * o.amount / 100 : Math.min(o.amount, p)));
    let bestD = disc(best, base);
    (item.variant_offers || []).forEach(vo => {
        const hit = (sizeIds || []).some(id => vo.ids.indexOf(parseInt(id, 10)) !== -1);
        if (!hit) return;
        const d = disc(vo, base);
        if (d > bestD) { bestD = d; best = vo; }
    });
    return best;
}
// Buy X get Y: free units are separate lines at price 0, kept in step with the paid lines
function syncFree() {
    cart = cart.filter(x => !x.auto_free);
    const extra = [];
    cart.forEach(x => {
        if (!x.buyget || !x.buyget.amount || !x.buyget.get_qty) return;
        const n = Math.floor(x.qty / x.buyget.amount) * x.buyget.get_qty;
        if (n <= 0) return;
        extra.push({ key: 'free|' + x.key, id: x.buyget.free_item_id, name: 'Free: ' + x.buyget.free_name + ' (' + x.buyget.name + ')',
                     price: 0, base: 0, qty: n, variants: [], size_ids: [], offer: null, buyget: null, auto_free: true, tax_free: 0 });
    });
    cart = cart.concat(extra);
}

function addToCart(item, variants, sizeIds = [], sizeNames = [], unitPrice = null) {
    const base = (unitPrice === null) ? parseFloat(item.price) : unitPrice;
    const o = pickOfferT(item, sizeIds, base);
    const price = linePriceT(base, o);
    const label = sizeNames.join(' + ');
    const key = item.id + '|' + sizeIds.join(',') + '|' + variants.join(',');
    let exist = cart.find(x => x.key === key);
    if (exist) { exist.qty++; }
    else {
        cart.push({
            key: key, id: item.id,
            name: item.item_name + (label ? ' (' + label + ')' : ''),
            price: price, base: base, offer: o, buyget: item.buyget || null, variants: variants, size_ids: sizeIds,
            qty: 1, tax_free: parseInt(item.is_tax_free || 0)
        });
    }
    render();
}

function updateQty(key, delta) {
    let idx = cart.findIndex(x => x.key === key);
    if(idx > -1 && !cart[idx].auto_free) {
        cart[idx].qty += delta;
        if(cart[idx].qty <= 0) cart.splice(idx, 1);
        render();
    }
}

function render() {
    syncFree();
    let html = '', sub = 0, taxable = 0;
    
    
    document.querySelectorAll('.item-qty-badge').forEach(b => b.style.display = 'none');
    document.querySelectorAll('.item-card').forEach(c => c.classList.remove('selected'));

    cart.forEach(i => {
        let total = i.price * i.qty;
        sub += total;
        if(i.tax_free === 0) taxable += total;

        let b = document.getElementById('badge-'+i.id);
        if(b) {
            let totalQtyForId = cart.filter(x => x.id == i.id).reduce((sum, x) => sum + x.qty, 0);
            b.innerText = totalQtyForId; b.style.display = 'flex';
            document.getElementById('card-'+i.id).classList.add('selected');
        }

        html += `
        <div style="display:flex; justify-content:space-between; margin-bottom:15px; padding-bottom:10px; border-bottom:1px solid #f1f5f9;">
            <div style="flex:1;">
                <div style="font-weight:600; font-size:14px;">${i.name}</div>
                <div style="font-size:12px; color:#64748b;">${i.qty} x ${i.price.toFixed(2)}৳ ${i.variants.length ? '<br>['+i.variants.join(', ')+']' : ''}</div>
                <div style="margin-top:5px;">
                    <button onclick="updateQty('${i.key}', -1)" style="border:1px solid #ddd; padding:2px 8px; border-radius:4px; cursor:pointer;">-</button>
                    <button onclick="updateQty('${i.key}', 1)" style="border:1px solid #ddd; padding:2px 8px; border-radius:4px; cursor:pointer;">+</button>
                </div>
            </div>
            <div style="font-weight:700;">${total.toFixed(2)}৳</div>
        </div>`;
    });

    document.getElementById('cart-list').innerHTML = cart.length ? html : '<div style="text-align:center; color:#94a3b8; margin-top:50px;">Empty Cart</div>';

    if(cart.length > 0) {
        
        let vat = taxable * (TAX_RATE / 100);       
        
        let sc = 0;
        let scDisplay = '';

        if(orderMeta.type === 'dine_in') {
            sc = sub * (SC_RATE / 100);
            scDisplay = `
                <div style="display:flex; justify-content:space-between; font-size:14px; color:#64748b; margin-bottom:5px;">
                    <span>S. Charge (${SC_RATE}%)</span><span>${sc.toFixed(2)}৳</span>
                </div>`;
        } else if (orderMeta.type === 'delivery') {
            scDisplay = `
                <div style="display:flex; justify-content:space-between; font-size:14px; color:#64748b; margin-bottom:5px;">
                    <span>Delivery Charge</span><span>0.00৳</span>
                </div>`;
        } else {
        scDisplay = `
                <div style="display:flex; justify-content:space-between; font-size:14px; color:#22c55e; margin-bottom:5px;">
                    <span>S. Charge</span><span>0.00৳ (Take Out)</span>
                </div>`;
        }

        let grand = sub + vat + sc;

        document.getElementById('cart-summary').innerHTML = `
            <div style="display:flex; justify-content:space-between; font-size:14px; color:#64748b; margin-bottom:5px;">
                <span>Subtotal</span><span>${sub.toFixed(2)}৳</span>
            </div>
            <div style="display:flex; justify-content:space-between; font-size:14px; color:#64748b; margin-bottom:5px;">
                <span>VAT (${TAX_RATE}%)</span><span>${vat.toFixed(2)}৳</span>
            </div>
            ${scDisplay}
            <div class="total-box" style="display:flex; justify-content:space-between; border-top: 1px dashed #ccc; padding-top:10px;">
                <span>Total</span><span>${grand.toFixed(2)}৳</span>
            </div>
            <button class="btn-place-order" style="margin-top:15px;" onclick="placeOrder(${grand})">PLACE ORDER</button>
        `;
    } else { 
        document.getElementById('cart-summary').innerHTML = ''; 
    }
}

function placeOrder(grandTotal) {
    const orderBtn = document.querySelector('.btn-place-order');
    if(orderBtn) {
        orderBtn.disabled = true;
        orderBtn.innerText = 'Placing...';
    }

    let sub = cart.reduce((sum, i) => sum + (i.price * i.qty), 0);
    let taxable = cart.filter(i => i.tax_free === 0).reduce((sum, i) => sum + (i.price * i.qty), 0);
    let vatVal = taxable * (TAX_RATE / 100);
    let scVal = (orderMeta.type === 'dine_in') ? sub * (SC_RATE / 100) : 0;

    let processedCart = cart.filter(i => !i.auto_free).map(item => {
        return {
            id: item.id,
            name: item.name,
            price: (item.base !== undefined ? item.base : item.price),
            qty: item.qty,
            variants_selected: item.variants ? item.variants.join(', ') : '',
            size_value_ids: (item.size_ids || []).join(',')
        };
    });

    jQuery.ajax({
        url: AJAX_URL,
        type: 'POST',
        data: {
            action: 'place_qr_order',
            restaurant_id: <?php echo $restaurant_id; ?>,
            table_id: orderMeta.table_id,
            order_type: orderMeta.type,
            order_source: orderMeta.type === 'self_service' ? 'self' : 'pos',
            customer_name: deliveryCustomer ? deliveryCustomer.name : '',
            customer_phone: deliveryCustomer ? deliveryCustomer.phone : '',
            delivery_address: deliveryCustomer ? deliveryCustomer.address : '',
            delivery_note: deliveryCustomer ? deliveryCustomer.note : '',
            items: JSON.stringify(processedCart),
            subtotal: sub,
            tax_amount: vatVal,
            service_charge: scVal,
            grand_total: grandTotal,
            security: NONCE
        },
        success: function(res) {
            if(res.success) { 
                document.getElementById('successPopup').style.display = 'flex';
                
                let timeLeft = 3;
                let timerElement = document.getElementById('timer');
                let countdown = setInterval(function() {
                    timeLeft--;
                    timerElement.innerText = timeLeft;
                    if(timeLeft <= 0) {
                        clearInterval(countdown);
                        location.reload();
                    }
                }, 1000);

            } else { 
                alert('Order Failed: ' + res.data); 
                resetOrderBtn(orderBtn);
            }
        },
        error: function(xhr) {
            alert('Server Error. Please try again.');
            resetOrderBtn(orderBtn);
        }
    });
}

function resetOrderBtn(btn) {
    if(btn) {
        btn.disabled = false;
        btn.innerText = 'PLACE ORDER';
    }
}


function showOccupiedAlert(tableName, takenBy, itemCount, timeAgo, placementTime) {
    document.getElementById('vBody').innerHTML = `
        <div style="text-align:center; padding:10px 0;">
            <div style="font-size:48px; margin-bottom:12px;">🔒</div>
            <h3 style="margin:0 0 8px; color:#1e293b;">${tableName} is Occupied</h3>
            <p style="color:#64748b; margin:0 0 20px; font-size:14px;">This table currently has an active order</p>
            <div style="background:#f8fafc; border-radius:12px; padding:16px; text-align:left; border:1px solid #e2e8f0;">
                <div style="display:flex; justify-content:space-between; margin-bottom:10px;">
                    <span style="color:#64748b; font-size:13px;">👤 Taken by</span>
                    <span style="font-weight:700; font-size:13px; color:#1e293b;">${takenBy}</span>
                </div>
                <div style="display:flex; justify-content:space-between; margin-bottom:10px;">
                    <span style="color:#64748b; font-size:13px;">🛒 Items</span>
                    <span style="font-weight:700; font-size:13px; color:#1e293b;">${itemCount} items</span>
                </div>
                <div style="display:flex; justify-content:space-between;">
                    <span style="color:#64748b; font-size:13px;">🕐 Order Time</span>
                    <span style="font-weight:700; font-size:13px; color:#1e293b;">${placementTime} (${timeAgo})</span>
                </div>
            </div>
            <button onclick="closeM()" class="btn-place-order" 
                    style="margin-top:20px; background:#1e293b;">
                Got it
            </button>
        </div>`;
    document.getElementById('vModal').style.display = 'flex';
}

function closeM() { document.getElementById('vModal').style.display = 'none'; }

// Category Filter
document.querySelectorAll('.cat-item[data-cat]').forEach(el => {
    el.onclick = function() {
        document.querySelectorAll('.cat-item').forEach(c => c.classList.remove('active'));
        this.classList.add('active');
        let cat = this.dataset.cat;
        document.querySelectorAll('.item-card').forEach(c => {
            c.style.display = (cat === 'all' || c.dataset.catId === cat) ? 'block' : 'none';
        });
    }
});

</script>