<?php
/**
 * Plugin Name: DineX Restro Solutions.
 * Tagline: Manage Smarter. Serve Faster. Grow Bigger.
 * Description: Streamline restaurant operations with AI-powered automation. Manage orders, kitchen workflows, inventory, POS, and customer experiences from a single platform.
 * Version: 1.11.9
 * Author: Nazmul Hosen
 * Links: www.nazmulh.com
 * Text Domain: dinex-restro-system
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// Define Constants
define( 'QRRS_PATH', plugin_dir_path( __FILE__ ) );
define( 'QRRS_URL', plugin_dir_url( __FILE__ ) );

class QR_Restaurant_System {

    public function __construct() {
        $this->includes();
        $this->maybe_upgrade_database();
        register_activation_hook( __FILE__, [ $this, 'activate' ] );
        $this->register_shortcodes();
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        $this->register_ajax_handlers();
    }

    private function includes() {
        require_once QRRS_PATH . 'includes/database.php';
        require_once QRRS_PATH . 'includes/auth.php';
        require_once QRRS_PATH . 'includes/helpers.php';

        require_once QRRS_PATH . 'includes/restaurant/restaurant-functions.php';
        require_once QRRS_PATH . 'includes/license/license-functions.php';
        require_once QRRS_PATH . 'includes/inventory/inventory-functions.php';
        require_once QRRS_PATH . 'includes/inventory/wastage.php';
        require_once QRRS_PATH . 'includes/inventory/variant-recipes.php';
require_once QRRS_PATH . 'includes/inventory/option-setup.php';
require_once QRRS_PATH . 'includes/restaurant/online-settings.php';
require_once QRRS_PATH . 'includes/restaurant/public-order.php';
require_once QRRS_PATH . 'includes/crm/crm.php';
require_once QRRS_PATH . 'includes/restaurant/otp.php';
require_once QRRS_PATH . 'includes/restaurant/rooms.php';
require_once QRRS_PATH . 'includes/restaurant/tracking.php';
require_once QRRS_PATH . 'includes/order/self-service.php';
require_once QRRS_PATH . 'includes/order/countdown.php';
require_once QRRS_PATH . 'includes/backup/backup.php';
require_once QRRS_PATH . 'includes/backup/restore.php';
require_once QRRS_PATH . 'includes/audit/audit.php';
require_once QRRS_PATH . 'includes/billing/void-refund.php';
require_once QRRS_PATH . 'includes/billing/split-payment.php';
require_once QRRS_PATH . 'includes/billing/ledger.php';
require_once QRRS_PATH . 'includes/billing/closing.php';
require_once QRRS_PATH . 'includes/reports/discount-split.php';
require_once QRRS_PATH . 'includes/reports/profit-loss.php';
require_once QRRS_PATH . 'includes/accounts/accounts.php';
require_once QRRS_PATH . 'includes/accounts/suppliers-pay.php';
require_once QRRS_PATH . 'includes/accounts/customer-due.php';
require_once QRRS_PATH . 'includes/reports/export.php';
require_once QRRS_PATH . 'includes/realtime/live.php';
require_once QRRS_PATH . 'includes/printer/printer.php';
require_once QRRS_PATH . 'includes/billing/receipt.php';
require_once QRRS_PATH . 'includes/hr/attendance.php';
require_once QRRS_PATH . 'includes/restaurant/roles.php';
require_once QRRS_PATH . 'includes/hr/leave-types.php';
require_once QRRS_PATH . 'includes/hr/leaves.php';

/**
 * Roles used by the restaurant system. A restaurant admin manages one restaurant from the
 * restaurant dashboard only; it has no access to wp-admin.
 */
add_action( 'init', function () {
    if ( ! get_role( 'qr_cashier' ) ) add_role( 'qr_cashier', 'Cashier', [ 'read' => true ] );
    if ( ! get_role( 'qr_restaurant_admin' ) ) add_role( 'qr_restaurant_admin', 'Restaurant Admin', [ 'read' => true ] );
}, 5 );

/** The role name shown under the user's name, in plain words. */
function qrrs_role_label( $user ) {
    $map = [
        'administrator'        => 'Administrator',
        'qr_restaurant_admin'  => 'Restaurant Admin',
        'qr_manager'           => 'Manager',
        'qr_waiter'            => 'Waiter',
        'qr_kitchen'           => 'Kitchen',
        'qr_cashier'           => 'Cashier',
    ];
    foreach ( (array) $user->roles as $r ) {
        if ( isset( $map[ $r ] ) ) return $map[ $r ];
    }
    return ! empty( $user->roles ) ? ucwords( str_replace( [ 'qr_', '_' ], [ '', ' ' ], $user->roles[0] ) ) : '';
}

/** Full access inside the restaurant system: the WordPress admin, or a restaurant admin. */
function qrrs_is_full_admin() {
    return current_user_can( 'administrator' ) || current_user_can( 'qr_restaurant_admin' );
}

/** Restaurant system users (not WordPress admins) do not get wp-admin or its admin bar. */
function qrrs_is_system_user_only( $user = null ) {
    $user = $user ?: wp_get_current_user();
    if ( ! $user || ! $user->ID ) return false;
    if ( in_array( 'administrator', (array) $user->roles, true ) ) return false;
    return ! empty( array_intersect( [ 'qr_manager', 'qr_waiter', 'qr_kitchen', 'qr_cashier', 'qr_restaurant_admin' ], (array) $user->roles ) );
}

add_action( 'admin_init', function () {
    if ( wp_doing_ajax() || wp_doing_cron() ) return;
    if ( qrrs_is_system_user_only() ) {
        wp_safe_redirect( home_url( '/restaurant-dashboard/' ) );
        exit;
    }
} );

add_filter( 'show_admin_bar', function ( $show ) {
    return qrrs_is_system_user_only() ? false : $show;
} );

/**
 * Staff access: an inactive staff member cannot sign in, and is signed out if the status
 * changes while they are logged in. Admins are not affected.
 */
/**
 * Why a staff member cannot use the system right now: 'inactive', 'leave', or '' (allowed).
 * Admins are never blocked here.
 */
function qrrs_staff_block_reason( $user ) {
    if ( ! $user || ! ( $user instanceof WP_User ) ) return '';
    if ( in_array( 'administrator', (array) $user->roles, true ) ) return '';
    global $wpdb;
    $staff_rows = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}qrrs_staff WHERE user_id = %d", $user->ID ) );
    $staff_roles = [ 'qr_manager', 'qr_waiter', 'qr_kitchen', 'qr_cashier' ];
    $has_role = ! empty( array_intersect( $staff_roles, (array) $user->roles ) );

    // not a member of this system at all
    if ( ! $staff_rows && ! $has_role ) return 'unauthorized';
    // a staff member who is not linked to any restaurant
    if ( $staff_rows ) {
        $linked = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}qrrs_staff WHERE user_id = %d AND restaurant_id > 0", $user->ID ) );
        if ( ! $linked ) return 'no_restaurant';
    }
    if ( 'inactive' === (string) get_user_meta( $user->ID, 'staff_status', true ) ) return 'inactive';

    $today = current_time( 'Y-m-d' );
    $on_leave = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}qrrs_leaves l
         JOIN {$wpdb->prefix}qrrs_staff s ON s.id = l.staff_id
         WHERE s.user_id = %d AND l.start_date <= %s AND l.end_date >= %s",
        $user->ID, $today, $today
    ) );
    return $on_leave > 0 ? 'leave' : '';
}

// Only an inactive or on-leave staff member is signed out while logged in
function qrrs_is_inactive_staff( $user ) {
    return in_array( qrrs_staff_block_reason( $user ), [ 'inactive', 'leave' ], true );
}

add_filter( 'authenticate', function ( $user ) {
    if ( ! ( $user instanceof WP_User ) ) return $user;
    $reason = qrrs_staff_block_reason( $user );
    if ( '' === $reason ) return $user;

    $messages = [
        'leave'         => 'You are on leave today. Access is off until your leave ends.',
        'inactive'      => 'Your account is inactive. Please ask the manager.',
        'unauthorized'  => 'You are not authorized to use this system. Please ask the admin for access.',
        'no_restaurant' => 'Your account is not assigned to any restaurant. Please ask the admin.',
    ];
    $msg = $messages[ $reason ] ?? 'Access is not allowed for this account.';
    // the login page shows this message once, for this visitor
    set_transient( 'qrrs_lm_' . md5( $_SERVER['REMOTE_ADDR'] ?? '' ), $msg, 60 );
    return new WP_Error( 'qrrs_blocked', $msg );
}, 30 );

add_action( 'init', function () {
    if ( is_user_logged_in() && qrrs_is_inactive_staff( wp_get_current_user() ) ) {
        wp_logout();
        wp_safe_redirect( home_url( '/restaurant-login/?inactive=1' ) );
        exit;
    }
} );
require_once QRRS_PATH . 'includes/inventory/alerts.php';
require_once QRRS_PATH . 'includes/offers/offers.php';
require_once QRRS_PATH . 'includes/kitchen/kot.php';

// Mark plugin app pages so the theme does not apply smooth-scroll (Lenis) to them.
add_filter( 'body_class', function ( $classes ) {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    if ( preg_match( '#/(restaurant-dashboard|waiter-dashboard|kitchen-dashboard|online-order|track-order)(/|\?|$)#', $uri ) ) {
        $classes[] = 'qrrs-app';
    }
    return $classes;
} );

// Allow .jfif images (a JPEG variant) in the media uploader
add_filter( 'upload_mimes', function ( $mimes ) {
    $mimes['jfif'] = 'image/jpeg';
    return $mimes;
} );
add_filter( 'wp_check_filetype_and_ext', function ( $data, $file, $filename, $mimes, $real_mime = '' ) {
    if ( empty( $data['ext'] ) || empty( $data['type'] ) ) {
        if ( 'jfif' === strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) ) && 'image/jpeg' === $real_mime ) {
            return [ 'ext' => 'jfif', 'type' => 'image/jpeg', 'proper_filename' => false ];
        }
    }
    return $data;
}, 10, 5 );
require_once QRRS_PATH . 'includes/inventory/order-stock.php';
        require_once QRRS_PATH . 'includes/menu/menu-functions.php';
        require_once QRRS_PATH . 'includes/order/order-functions.php';
        require_once QRRS_PATH . 'includes/subscriptions/subscription-functions.php';
        require_once QRRS_PATH . 'includes/waiter/waiter-functions.php';

        require_once QRRS_PATH . 'includes/reports/report-functions.php';

        if ( file_exists( QRRS_PATH . 'includes/kitchen/kitchen-functions.php' ) ) {
            require_once QRRS_PATH . 'includes/kitchen/kitchen-functions.php';
        }

        require_once QRRS_PATH . 'includes/menu/public-menu-shortcode.php';
        require_once QRRS_PATH . 'includes/menu/category-shortcode.php';
        
        // Report AJAX Handlers
        require_once QRRS_PATH . 'includes/reports/handlers/sales-handler.php';
        require_once QRRS_PATH . 'includes/reports/handlers/item-wise-handler.php';
        require_once QRRS_PATH . 'includes/reports/handlers/category-wise-handler.php';
        require_once QRRS_PATH . 'includes/reports/handlers/order-type-handler.php';
        require_once QRRS_PATH . 'includes/reports/handlers/order-report-handler.php';
        require_once QRRS_PATH . 'includes/reports/handlers/kitchen-report-handler.php';
        require_once QRRS_PATH . 'includes/reports/handlers/staff-report-handler.php';
        require_once QRRS_PATH . 'includes/reports/handlers/payment-tax-handler.php';
    }

    private function maybe_upgrade_database() {
        $schema_version = get_option( 'qrrs_inventory_schema_version' );

        if ( '1.1.0' === $schema_version ) {
            return;
        }

        if ( class_exists( 'QRRS_Database' ) ) {
            QRRS_Database::create_tables();
            update_option( 'qrrs_inventory_schema_version', '1.1.0' );
        }
    }

    public function activate() {
        if ( class_exists( 'QRRS_Database' ) ) {
            QRRS_Database::create_tables();
        }
        $this->create_frontend_pages();

        if ( ! get_option( 'qrrs_plugin_installed_at' ) ) {
            
            $wp_timezone = wp_timezone();
            $local_now   = new DateTime('now', $wp_timezone);
            
            update_option( 'qrrs_plugin_installed_at', $local_now->format('Y-m-d H:i:s') );
        }

        flush_rewrite_rules();
    }

    private function create_frontend_pages() {
        $pages = [
            'restaurant-login'     => [ 'title' => 'Restaurant Login', 'content' => '[qrrs_login]' ],
            'restaurant-dashboard' => [ 'title' => 'Admin Dashboard', 'content' => '[qrrs_admin_dashboard]' ],
            'waiter-dashboard'     => [ 'title' => 'Waiter Dashboard', 'content' => '[qrrs_waiter_dashboard]' ],
            'kitchen-dashboard'    => [ 'title' => 'Kitchen Display', 'content' => '[qrrs_kitchen_dashboard]' ],
            'billing-counter'      => [ 'title' => 'Billing & POS', 'content' => '[qrrs_billing_counter]' ],
            'restaurant-menu'      => [ 'title' => 'Digital Menu', 'content' => '[qrrs_digital_menu]' ],
        ];

        foreach ( $pages as $slug => $data ) {
            if ( ! get_page_by_path( $slug ) ) {
                wp_insert_post( [
                    'post_title'   => $data['title'],
                    'post_content' => $data['content'],
                    'post_status'  => 'publish',
                    'post_type'    => 'page',
                    'post_name'    => $slug,
                ] );
            }
        }
    }

    private function register_shortcodes() {

        add_shortcode( 'qrrs_login', function() {
            ob_start();
            include QRRS_PATH . 'templates/frontend/login.php';
            return ob_get_clean();
        });

        add_shortcode( 'qrrs_admin_dashboard', function() {
            ob_start();
            include QRRS_PATH . 'templates/dashboard/dashboard.php';
            return ob_get_clean();
        });

        add_shortcode( 'qrrs_waiter_dashboard', function() {
            ob_start();
            include QRRS_PATH . 'templates/dashboard/waiter.php';
            return ob_get_clean();
        });

        add_shortcode( 'qrrs_kitchen_dashboard', function() {
            ob_start();
            include QRRS_PATH . 'templates/dashboard/kitchen.php';
            return ob_get_clean();
        });

        add_shortcode( 'qrrs_digital_menu', function() {
            ob_start();
            include QRRS_PATH . 'templates/frontend/menu.php';
            return ob_get_clean();
        });

        add_shortcode( 'qrrs_billing_counter', function() {
            ob_start();
            if ( file_exists( QRRS_PATH . 'templates/dashboard/take-order.php' ) ) {
                include QRRS_PATH . 'templates/dashboard/take-order.php';
            }
            return ob_get_clean();
        });

        add_shortcode( 'staff_profile', function() {
            if ( is_user_logged_in() ) {
                ob_start();
                include QRRS_PATH . 'includes/user/profile.php';
                return ob_get_clean();
            }
        });
    }

    public function enqueue_assets() {

        wp_enqueue_media();
        wp_enqueue_script('jquery');

        // --- External Styles ---
        wp_enqueue_style( 'bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css', array(), '5.3.3' );
        wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css', array(), '6.5.1' );
        wp_enqueue_style( 'flatpickr-css', 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css', array(), '4.6.13' );
        wp_enqueue_style(
            'material-icons-outlined',
            'https://fonts.googleapis.com/css2?family=Material+Icons+Outlined&display=block',
            array(),
            null
        );

        // --- Custom Styles ---
        wp_enqueue_style(
            'qrrs-frontend-style',
            QRRS_URL . 'assets/css/frontend.css',
            ['bootstrap-css'],
            '1.2.0'
        );

        // --- External Scripts ---
        wp_enqueue_script( 'chart-js', 'https://cdn.jsdelivr.net/npm/chart.js', [], '4.4.2', true );
        wp_enqueue_script( 'flatpickr-js', 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.js', [], '4.6.13', true );
        wp_enqueue_script( 'bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js', array('jquery'), '5.3.3', true );

        // --- Custom Scripts ---
        wp_enqueue_script(
            'qrrs-app-js',
            QRRS_URL . 'assets/js/app.js',
            ['jquery', 'bootstrap-js'],
            '1.2.0',
            true
        );

        wp_localize_script('qrrs-app-js', 'qrrs_vars', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('qrrs_nonce_action'),
            'qr_nonce' => wp_create_nonce('qr_order_nonce')
        ]);

        $plugin_pages = array('restaurant-login', 'restaurant-dashboard', 'waiter-dashboard', 'kitchen-dashboard', 'billing-counter', 'restaurant-menu');

        if ( is_page($plugin_pages) ) {
            $custom_css = "
                .site-header, .site-footer, .header, .footer, #masthead, #colophon {
                    display: none !important;
                }
                body { padding-top: 0 !important; margin-top: 0 !important; }
            ";
            wp_add_inline_style( 'qrrs-frontend-style', $custom_css );
        }
    }

    private function register_ajax_handlers() {
        add_action('wp_ajax_place_qr_order', 'handle_qr_order_placement');
        add_action('wp_ajax_nopriv_place_qr_order', 'handle_qr_order_placement');

        add_action('wp_ajax_fetch_pos_items', 'fetch_pos_items_handler');
        add_action('wp_ajax_nopriv_fetch_pos_items', 'fetch_pos_items_handler');

        add_action('wp_ajax_update_dashboard_order_status', 'handle_update_dashboard_order_status');

        add_action('wp_ajax_fetch_sales_report_data', 'handle_fetch_sales_report_data');
        add_action('wp_ajax_fetch_item_wise_report', 'handle_fetch_item_wise_report');

        add_action('wp_ajax_qrrs_set_active_restaurant', [$this, 'handle_set_active_restaurant']);
    }

    public function handle_set_active_restaurant() {
        check_ajax_referer('qrrs_nonce_action', 'security');
        if ( current_user_can('manage_options') ) {
            $res_id = intval($_POST['res_id']);
            update_user_meta( get_current_user_id(), 'qrrs_selected_res_id', $res_id );
            wp_send_json_success(['message' => 'Restaurant Updated']);
        }
        wp_send_json_error('Unauthorized');
    }
}

/**
 * AJAX: POS Item Fetching
 */
function fetch_pos_items_handler() {
    check_ajax_referer('qrrs_nonce_action', 'security');
    global $wpdb;

    $restaurant_id = isset($_POST['restaurant_id']) ? intval($_POST['restaurant_id']) : 0;
    $category_id   = isset($_POST['category_id']) ? intval($_POST['category_id']) : 0;

    if ( ! $restaurant_id ) { wp_send_json_error('Invalid Restaurant ID'); }

    $query  = "SELECT * FROM {$wpdb->prefix}qrrs_items WHERE restaurant_id = %d AND is_available = 1";
    $params = [$restaurant_id];

    if ( $category_id > 0 ) {
        $query   .= " AND category_id = %d";
        $params[] = $category_id;
    }

    $items = $wpdb->get_results($wpdb->prepare($query, $params));
    if ( $wpdb->last_error ) { wp_send_json_error($wpdb->last_error); }

    $data = [];
    if ( $items ) {
        foreach ( $items as $item ) {
            $img = '';
            if ( ! empty($item->image_url) )   { $img = $item->image_url; }
            elseif ( ! empty($item->item_image) ) { $img = $item->item_image; }
            elseif ( ! empty($item->image) )   { $img = $item->image; }

            $data[] = [
                'id'       => (int) $item->id,
                'name'     => ! empty($item->item_name) ? $item->item_name : ( $item->name ?? 'Unnamed' ),
                'price'    => (float) $item->price,
                'image'    => $img,
                'variants' => $item->variants ?? $item->variants_json ?? '[]'
            ];
        }
    }
    wp_send_json_success($data);
}

/**
 * AJAX: QR Order Placement
 */
function handle_qr_order_placement() {
    if ( ! isset($_POST['security']) || ! wp_verify_nonce($_POST['security'], 'qr_order_nonce') ) {
        wp_send_json_error('Security check failed.');
    }

    global $wpdb;
    $order_table = $wpdb->prefix . 'qrrs_orders';
    $items_table = $wpdb->prefix . 'qrrs_order_items';
    $tables_db   = $wpdb->prefix . 'qrrs_tables';

    $res_id   = intval($_POST['restaurant_id']);
    $table_id = intval($_POST['table_id']);
    $order_type = sanitize_key( $_POST['order_type'] ?? 'take_out' );
    $requested_source = sanitize_key( $_POST['order_source'] ?? 'qr' );
    $items    = json_decode(wp_unslash($_POST['items']), true);

    if ( empty($items) ) { wp_send_json_error('Cart is empty.'); }

    if ( ! $res_id || ! in_array( $order_type, [ 'dine_in', 'take_out', 'delivery', 'room_service', 'self_service' ], true ) ) {
        wp_send_json_error( 'Invalid order details.' );
    }

    // Server recalculates every line (price, size, add-ons). The browser's prices are not trusted.
    $checked = qrrs_validate_order_items( $res_id, $items );
    if ( is_string( $checked ) ) {
        wp_send_json_error( $checked );
    }
    $items            = $checked['lines'];
    $checked_subtotal = $checked['subtotal'];
    $checked_taxable  = $checked['taxable'];

    $is_pos_order = $requested_source === 'pos'
        && is_user_logged_in()
        && function_exists( 'qrrs_current_user_can_operate_restaurant' )
        && qrrs_current_user_can_operate_restaurant( $res_id );
    $order_source = $is_pos_order ? 'pos' : ( 'self' === $requested_source ? 'self' : 'qr' );

    if ( 'delivery' === $order_type && function_exists( 'qrrs_can_use_feature' ) && ! qrrs_can_use_feature( 'delivery' ) ) {
        wp_send_json_error( 'Delivery orders are available in Pro only.' );
    }

    // Customer details. Mandatory for customer-facing orders (online, delivery, table QR = source 'qr').
    // Counter and waiter orders may leave them empty.
    $cust_name  = sanitize_text_field( wp_unslash( $_POST['customer_name'] ?? '' ) );
    $cust_phone = qrrs_normalize_phone( sanitize_text_field( wp_unslash( $_POST['customer_phone'] ?? '' ) ) );
    $cust_addr  = sanitize_textarea_field( wp_unslash( $_POST['delivery_address'] ?? '' ) );
    $cust_note  = sanitize_textarea_field( wp_unslash( $_POST['delivery_note'] ?? '' ) );
    $source     = sanitize_key( $_POST['order_source'] ?? '' );
    $staff_self = 'self' === $source && is_user_logged_in()
        && function_exists( 'qrrs_current_user_can_operate_restaurant' )
        && qrrs_current_user_can_operate_restaurant( $res_id );
    $customer_required = ( 'qr' === $source ) || ( 'self' === $source && ! $staff_self ) || ( 'delivery' === $order_type );
    if ( $customer_required ) {
        if ( mb_strlen( trim( $cust_name ) ) < 2 || ! preg_match( '/^01[3-9]\d{8}$/', $cust_phone ) ) {
            wp_send_json_error( 'Please enter your name and a valid mobile number.' );
        }
        if ( 'delivery' === $order_type && mb_strlen( trim( $cust_addr ) ) < 5 ) {
            wp_send_json_error( 'Please enter your delivery address.' );
        }
    }
    $delivery_customer = [];
    if ( '' !== $cust_name || '' !== $cust_phone ) {
        $delivery_customer = [
            'customer_name'    => $cust_name,
            'customer_phone'   => $cust_phone,
            'delivery_address' => $cust_addr,
            'delivery_note'    => $cust_note,
        ];
    }

    $subtotal       = floatval($_POST['subtotal']);
    if ( abs( $subtotal - $checked_subtotal ) > 0.01 ) {
        wp_send_json_error( 'Prices have changed. Please refresh the page and try again.' );
    }
    $tax_amount     = floatval($_POST['tax_amount']);
    $service_charge = floatval($_POST['service_charge']);
    $grand_total    = floatval($_POST['grand_total']);

    // VAT, service charge and total are calculated here from the restaurant's rates.
    // The browser's numbers must match; otherwise the order is not taken.
    // Delivery charge comes only from the server-side public order check (never from the request).
    $delivery_charge = ( 'delivery' === $order_type && isset( $GLOBALS['qrrs_public_delivery_charge'] ) )
        ? floatval( $GLOBALS['qrrs_public_delivery_charge'] )
        : 0.0;
    $charges = qrrs_compute_charges( $res_id, $checked_subtotal, $checked_taxable, $order_type, $delivery_charge );
    if (
        abs( $tax_amount - $charges['vat'] ) > 0.01 ||
        abs( $service_charge - $charges['sc'] ) > 0.01 ||
        abs( $grand_total - $charges['grand'] ) > 0.01
    ) {
        wp_send_json_error( 'Prices have changed. Please refresh the page and try again.' );
    }
    $tax_amount     = $charges['vat'];
    $service_charge = $charges['sc'];
    $grand_total    = $charges['grand'];

    $final_table_name = 'Take Out';
    if ( $table_id > 0 ) {
        $db_table_name = $wpdb->get_var($wpdb->prepare("SELECT table_name FROM $tables_db WHERE id = %d", $table_id));
        if ( $db_table_name ) { $final_table_name = $db_table_name; }
    } elseif ( 'delivery' === $order_type ) {
        $final_table_name = 'Delivery';
    } elseif ( 'dine_in' === $order_type ) {
        $final_table_name = 'Counter';
    } elseif ( 'self_service' === $order_type ) {
        $final_table_name = 'Self-service';
    }

    
    $wp_timezone = wp_timezone();
    $local_now   = new DateTime('now', $wp_timezone);
    $kitchen_settings = function_exists( 'qrrs_get_restaurant_kitchen_settings' )
        ? qrrs_get_restaurant_kitchen_settings( $res_id )
        : [ 'mode' => 'active_kitchen', 'capacity' => 1 ];
    if ( 'self' === $order_source ) {
        $order_status        = 'awaiting_payment';
        $verification_status = 'approved';
    } else {
        $order_status = $order_source === 'qr'
            ? 'awaiting_verification'
            : ( $kitchen_settings['mode'] === 'ready_food' ? 'ready' : 'pending' );
        $verification_status = $order_source === 'qr' ? 'pending' : 'approved';
    }

    // Self-service: a daily token number that restarts at 0001 each day
    $token_no   = '';
    $token_date = null;
    $want_token = 'self' === $order_source
        || ( 'qr' !== $order_source && function_exists( 'qrrs_online_services_for' ) && ! empty( qrrs_online_services_for( $res_id )['self_service'] ) );
    if ( $want_token ) {
        $token_date = $local_now->format( 'Y-m-d' );
        $last_token = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COALESCE(MAX(CAST(token_no AS UNSIGNED)), 0) FROM {$wpdb->prefix}qrrs_orders WHERE restaurant_id = %d AND token_date = %s",
            $res_id, $token_date
        ) );
        $token_no = str_pad( (string) ( $last_token + 1 ), 4, '0', STR_PAD_LEFT );
    }

    $order_data = [
        'restaurant_id'  => $res_id,
        'table_name'     => $final_table_name,
        'order_type'     => $order_type,
        'order_source'   => $order_source,
        'verification_status' => $verification_status,
        'waiter_id'      => get_current_user_id(),
        'total_amount'   => $subtotal,
        'tax_amount'     => $tax_amount,
        'service_charge' => $service_charge,
        'grand_total'    => $grand_total,
        'delivery_charge'=> $charges['delivery'],
        'order_status'   => $order_status,
        'token_no'       => $token_no,
        'token_date'     => $token_date,
        'ready_at'       => $order_status === 'ready' ? $local_now->format('Y-m-d H:i:s') : null,
        'payment_status' => 'unpaid',
        'created_at'     => $local_now->format('Y-m-d H:i:s') // 👈 লোকাল ডিভাইস টাইম পুশ করা হলো
    ];

    $inserted = $wpdb->insert($order_table, $order_data);
    if ( $inserted === false ) { wp_send_json_error('DB Order Error: ' . $wpdb->last_error); }

    $order_id = $wpdb->insert_id;

    if ( $delivery_customer ) {
        $customer_inserted = $wpdb->insert(
            $wpdb->prefix . 'qrrs_order_customers',
            array_merge( [
                'order_id'      => $order_id,
                'restaurant_id' => $res_id,
                'created_at'    => $local_now->format('Y-m-d H:i:s'),
            ], $delivery_customer ),
            [ '%d', '%d', '%s', '%s', '%s', '%s', '%s' ]
        );

        if ( $customer_inserted && function_exists( 'qrrs_crm_upsert' ) ) {
            qrrs_crm_upsert( $res_id, $cust_name, $cust_phone, $cust_addr );
        }

        if ( false === $customer_inserted ) {
            $wpdb->delete( $order_table, [ 'id' => $order_id ], [ '%d' ] );
            wp_send_json_error( 'Could not save delivery customer details.' );
        }
    }

    foreach ( $items as $item ) {
        $wpdb->insert($items_table, [
            'order_id'          => $order_id,
            'item_id'           => intval($item['id']),
            'restaurant_id'     => $res_id,
            'item_name'         => sanitize_text_field($item['name']),
            'variants_selected' => sanitize_text_field($item['variants_selected']),
            'size_value_ids'    => sanitize_text_field($item['size_value_ids'] ?? ''),
            'size_name'         => sanitize_text_field($item['size_name'] ?? ''),
            'quantity'          => intval($item['qty']),
            'price'             => function_exists( 'qrrs_offer_price_for_order_item' ) ? qrrs_offer_price_for_order_item( $order_id, intval( $item['id'] ?? 0 ), floatval( $item['price'] ), $item['size_value_ids'] ?? '', intval( $item['qty'] ?? 1 ) ) : floatval( $item['price'] ),
            'item_status'       => $order_status === 'ready' ? 'ready' : 'pending'
        ]);
    }
    $track_code = function_exists( 'qrrs_make_track_code' ) ? qrrs_make_track_code( $order_table ) : '';
    if ( $track_code ) {
        $wpdb->update( $order_table, [ 'tracking_code' => $track_code ], [ 'id' => $order_id ] );
    }
    $placed = apply_filters( 'qrrs_order_placed_response', 'Order placed successfully!', [
        'order_id'   => (int) $order_id,
        'track_code' => $track_code,
        'token_no'   => $token_no,
    ] );
    wp_send_json_success( $placed );
}

/**
 * AJAX: Order Status Update
 */
function handle_update_dashboard_order_status() {
    check_ajax_referer('qr_order_nonce', 'security');

    if ( ! current_user_can('manage_options') && ! current_user_can('qrrs_waiter') ) {
        wp_send_json_error('Unauthorized');
    }

    if ( ! isset($_POST['order_id']) || ! isset($_POST['status']) ) {
        wp_send_json_error('Missing data.');
    }

    global $wpdb;
    $order_id    = intval($_POST['order_id']);
    $status      = sanitize_text_field($_POST['status']);
    $order_table = $wpdb->prefix . 'qrrs_orders';

    $update_data = array('order_status' => $status);

    $wp_timezone = wp_timezone();
    $local_now   = new DateTime('now', $wp_timezone);
    $exact_time  = $local_now->format('Y-m-d H:i:s');

    if ( $status === 'ready' || $status === 'served' ) {
        $update_data['ready_at'] = $exact_time;
    }

    if ( $status === 'paid' ) {
        $update_data['payment_status'] = 'paid';
        $update_data['order_status']   = 'completed';
    }

    $updated = $wpdb->update(
        $order_table,
        $update_data,
        array('id' => $order_id)
    );

    if ( $updated !== false ) {
        do_action( 'qrrs_order_status_changed', $order_id, $status );
        $wpdb->update(
            $wpdb->prefix . 'qrrs_order_items',
            array('item_status' => $status),
            array('order_id' => $order_id)
        );
        wp_send_json_success('Order status updated to ' . $status);
    } else {
        wp_send_json_error('Database update failed: ' . $wpdb->last_error);
    }
}

new QR_Restaurant_System();